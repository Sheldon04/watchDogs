Page({

  data: {
    date: '',
    show: false,
    minDate: new Date().setMonth(new Date().getMonth()-3),
    maxDate: new Date().getTime(),
  },

  onDisplay() {
    this.setData({ show: true });
  },
  onClose() {
    this.setData({ show: false });
  },
  formatDate(date) {
    date = new Date(date);
    return `${date.getMonth() + 1}/${date.getDate()}`;
  },
  onConfirm(event) {
    this.setData({
      show: false,
      date: this.formatDate(event.detail),
    });
  },

});