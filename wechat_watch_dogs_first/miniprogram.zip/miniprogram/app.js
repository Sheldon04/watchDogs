//app.js
App({
  onLaunch: function () {

    wx.cloud.init({
      traceUser: true,
      env:"cloud1-4glvb4tta48f9654",
    })

    this.globalData = {}
  }
})
