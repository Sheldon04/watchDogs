const envList = [{"envId":"cloud1-4glvb4tta48f9654","alias":"cloud1"}]
const isMac = false
module.exports = {
    envList,
    isMac
}